from django.apps import AppConfig


class WebnewsConfig(AppConfig):
    name = 'WebNews'
