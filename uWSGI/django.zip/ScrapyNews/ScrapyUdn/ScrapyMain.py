import time
import os

while True:
    os.system("scrapy crawl udn")
    time.sleep(30)